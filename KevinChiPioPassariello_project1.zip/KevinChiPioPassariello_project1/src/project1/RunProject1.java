package project1;

/**
 * RunProject1 class is the driver that runs project 1.
 * 
 * @author Kevin Chi, Pio Passariello
 */
public class RunProject1 {
    /**
     * Main method to run the registration system.
     * 
     * @param args command line arguments
     */
    public static void main(String[] args) {
        new Frontend().run();
    }
}
